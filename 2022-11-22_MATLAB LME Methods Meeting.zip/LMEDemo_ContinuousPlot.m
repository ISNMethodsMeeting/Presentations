% Display standard continuous variable interaction for linear mixed model
% [this is poorly evaluated/possibly not generalized, use with caution]
%
% LMEDemo_ContinuousPlot(lme,varName,xVarName[,xVarIndex][,yLims])
% lme       - lme (fitlme object)
% varName   - continuous variable to display using its +/-1 SD (must exist in lme.Variables)
% xVarName  - x axis variable across which varName is displayed (must exist in lme.Variables)
% xVarIndex - (optional) filter for only certain levels of xVarName (e.g. restrict to session 1)
% ylims     - (optional) restrict ylim of figure to yLims
%
% Output
% (optional) F - figure handle for further processing
%
% Version: 1.0
% Author: Bjoern Horing, bjoern.horing@gmail.com
% Date: 2022-11-21
% [based on LMEContinuousPlot]

function varargout = LMEDemo_ContinuousPlot(lme,varName,xVarName,xVarIndex,yLims)

    eval(sprintf('%s = %1.5f;',varName,0)); % IV instantiation
    T = lme.Variables;
    Intercept = 1; % IV; these variables will be used via EVAL by their actual name, below
    C = [lme.Coefficients.Estimate lme.Coefficients.Lower lme.Coefficients.Upper]; % lower and upper unused atm
    CT = lme.Coefficients.Name;    
    
    % obtain target variable's Auspraegungen
    if exist(xVarName,'var') && ~isempty(xVarName)
        subT = T(T.(xVarName)==xVarIndex,:); % filter by some variable
    else
        subT = T;
    end
    se1 = nanstd(subT.(varName));
    seSpan = [-se1 0 se1];
    
    % style input
    labelz1 = {'low','0','high'};    
    labelcolors(1,:) = [0.8 0.8 0.8];
    labelcolors(2,:) = [0.4 0.4 0.4];
    labelcolors(3,:) = [0 0 0];
    labelstyle{1} = ':';
    labelstyle{2} = '-';
    labelstyle{3} = ':';
    
    ux = unique(T.(xVarName));
    
    F = figure;
    A = axes;
    hold on;
    
    for iii = 1:numel(seSpan)
        cc = seSpan(iii);   
        eval(sprintf('%s = %1.5f;',varName,cc));
        
        imCPred = [];
        for xxx = 1:numel(ux)
        
            eval(sprintf('%s = %1.5f;',xVarName,ux(xxx)));
            
            y = 0;
            for est = 1:size(C,1) % loop through all estimates, increment y at each go
                termName = regexprep(CT{est},'\:','*');
                termName = regexprep(termName,'[\(\)]',''); % for (Intercept)
                y  = y  + C(est,1)*eval(termName); % term*Name will multiply nicely
            end
            imCPred(xxx,1) = y; % could be >1; what?
        
        end
                    
        figure(F);   
        
        plot(1:numel(ux),imCPred,'Color',labelcolors(iii,:),'LineWidth',3,'LineStyle',labelstyle{iii})
            
    end

    figure(F);   
    xlim([0.5 numel(ux)+0.5])
    if exist('yLims','var')
        ylim(yLims);
    end
    legend(labelz1)      
    xticks(1:numel(ux))            
    xlabel(xVarName);
    ylabel(lme.ResponseName);
    title(sprintf('%s by %s%s1SD',regexprep(lme.ResponseName,'\_','\\_'),regexprep(varName,'\_','\\_'),char(0177)));
    
    if nargout
        varargout{1} = F;
    end
  