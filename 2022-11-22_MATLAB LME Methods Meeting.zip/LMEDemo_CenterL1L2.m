% Returns variables properly centered for HLM analyses, distinguishing first and second level variance, based on
% Hofmann, D. A., & Gavin, M. B. (1998). Centering decisions in hierarchical linear models: Implications for research in organizations. Journal of Management, 24(5), 623–641. doi: 10.1177/014920639802400504
%
% data = CenterL1L2(data,sbVarTag,varList[,moreMeans])
% data      - data (table)
% sbVarTag  - column name of subject (or more generally, first level entity) identifier (string)
% varList   - column name(s) of to-be-centered variable(s) (cell array)
% moreMeans - (optional) adds mean of means and sample mean (any)
%
% Version: 1.2
% Author: Bjoern Horing, bjoern.horing@gmail.com
% Date: 2021-06-15
%
% Version notes
% 1.2
% - corrected grand mean (m2) for unequal n, added mean of means (m3) and sample mean (m4)
%
% 1.1
% - function description, comments for Git

function data = LMEDemo_CenterL1L2(data,sbVarTag,varList,moreMeans)

    allSbs = unique(data.(sbVarTag));
    allSbs = allSbs(~isnan(allSbs));
    
    for v = 1:numel(varList)
        varName = varList{v};

        m1List = NaN(1,numel(allSbs));
        for sb = 1:numel(allSbs)
            sbId = allSbs(sb);        
            m1 = mean(data.(varName)(data.(sbVarTag)==sbId),'omitnan'); % subject mean
            data.(['m1' varName])(data.(sbVarTag)==sbId) = m1;
            m1List(sb) = m1;
        end
        data.(['c1' varName]) = data.(varName)-data.(['m1' varName]); % L1 centered
        data.(['m2' varName]) = repmat(mean(m1List,'omitnan'),size(data,1),1); % grand mean
        data.(['c2' varName]) = data.(['m1' varName])-mean(data.(['m2' varName]),'omitnan'); % L2 centered
        if exist('moreMeans','var') && moreMeans
            data.(['m3' varName]) = repmat(mean(data.(['m1' varName]),'omitnan'),size(data,1),1); % bonus: mean of means
            data.(['m4' varName]) = mean(data.(varName),'omitnan'); % bonus: sample mean
        end
    end
    