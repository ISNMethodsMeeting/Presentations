% Define contrasts by selecting specific terms from lme.Coefficient.Name list
%
% def = LMEDemo_DefineCon(lme,regList,[,con][,def])
% lme       - lme (fitlme object)
% regList   - cell array of regular expressions to apply
% con       - (optional) contrast type ('T' or 'F'; default 'T')
% def       - (optional) existing contrast definition to be (re)formatted
%
% Output
% def       - contrast definition
%
% Version: 1.0
% Author: Bjoern Horing, bjoern.horing@gmail.com
% Date: 2022-09-01

function def = LMEDemo_DefineCon(lme,regList,con,def)

    if ~exist('con','var')
        con = 'T';
    end
    if ~exist('def','var')
        def = [];
    end
    
    if strcmp(con,'T')
        
        def = zeros(1,numel(lme.CoefficientNames));
        for r = 1:numel(regList)
            reg = regList{r};
            def = def + cellfun(@(x) ~isempty(regexp(x,reg,'ONCE')),lme.CoefficientNames);
        end
        
        % sanity check
        if any(def>1)
            fprintf('[ ');
            fprintf('%d ',def);
            fprintf(']\n');
            error('Something went wrong. T contrast has weights above 1...');        
        end
        
    elseif strcmp(con,'F')
        
        def = [];
        for r = 1:numel(regList)
            reg = regList{r};
            def(r,:) = cellfun(@(x) ~isempty(regexp(x,reg,'ONCE')),lme.CoefficientNames);
        end 
        if any(sum(def,2)>1) % then we need to decompose lines with multiple hits into a proper F con
            def = ArrangeF(def);
        end
        
    elseif strcmp(con,'TToF')
        
        def = ArrangeF(def);
        
    end
    
    
function def = ArrangeF(def)
        
    rowMH = find(sum(def,2)>1);

    for ii = 1:numel(rowMH)
        row = rowMH(ii);
        colMH = find(def(row,:));
        newDef = zeros(numel(colMH),size(def,2));
        for cc = 1:numel(colMH)
            newDef(cc,colMH(cc)) = 1;
        end
        def = [def;newDef];        
    end

    % remove compound lines
    def(rowMH,:) = []; 
    
    % sort F contrast by weight order
    [~,col] = find(def); 
    [~,nS] = sort(col);
    def = def(nS,:);
    
    
    