% Poorly commented script for
% All from a single source (code) - Linear mixed models in MATLAB
% Bjoern Horing, Department of Systems Neuroscience, University Medical Center Hamburg-Eppendorf
% 2022-11-22
%
% Also see /docs/ for presentation

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% - - - - - - - - - - - - - - - 
% - - - - - - - - - - - - - - -     
% - - - - - - - - - - - - - - - 
% GET ENVIRONMENT, DATA
baseDir = ''; % YOUR PATH! Location of zip file contents 
if isempty(baseDir) % fine then...
    fP = mfilename('fullpath');
    [baseDir,~,~] = fileparts(fP);
end

addpath(baseDir);
[data,data_LFFull,data_LFPrePost,data_LFDeltas] = LMEDemo_GetData(baseDir);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% - - - - - - - - - - - - - - - 
% - - - - - - - - - - - - - - - 
% - - - - - - - - - - - - - - - 
% 0: UNDERSTANDING THE LME OBJECT (commandline versus data view)
lmeNull1 = fitlme(data_LFPrePost,'VAS1 ~ 1 + (1|SbId)','StartMethod','default','FitMethod','REML','CheckHessian',true)
% click class object
lmeProperties = properties(lmeNull1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% - - - - - - - - - - - - - - - 
% - - - - - - - - - - - - - - - 
% - - - - - - - - - - - - - - - 
% 1.1: NESTING REQUIREMENTS
% First requirement of LME is whether the data is meaningfully nested to begin with, otherwise LME would not help anyway
% SPSS (gasp!) ground truth
LMEDemo_Nesting(lmeNull1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% - - - - - - - - - - - - - - - 
% - - - - - - - - - - - - - - -     
% - - - - - - - - - - - - - - - 
% 1.2: NORMALITY OF RESIDUALS REQUIREMENT
% What if it isn't met? Transformation, weighting
figure;plotResiduals(lmeNull1);   
figure;normplot(residuals(lmeNull1)');
figure;qqplot(residuals(lmeNull1)');

R = normalitytest(residuals(lmeNull1)'); % input as row vector!

% Now we need to decide which predictors to use, and do some preprocessing

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% - - - - - - - - - - - - - - -      
% - - - - - - - - - - - - - - - 
% - - - - - - - - - - - - - - - 
% 2: The relevance (& importance?) of centering

% - - - - - - - - - - - - - - - 
% Example 2.1: Uncentered case
subData = data_LFPrePost(data_LFPrePost.PrePost==2,:);
noCLme = fitlme(subData,'VAS1 ~ Segment + (1|SbId)','StartMethod','default','FitMethod','REML')

figure;
S1 = subplot(1,2,1);
scatter(subData.Segment,noCLme.response,'kx');
xlim([-0.5 6.5]);
lsline;
xlabel('Segment');
ylabel('Raw VAS (visual analogue scale)');

S2 = subplot(1,2,2);
hold on;    
scatter(subData.Segment,predict(noCLme),'kx');
xlim([-0.5 6.5]);
ylim(S1.YLim);
lsline;
xlabel('Segment');
ylabel('Predicted VAS');    

% zoom in
line([0 0],ylim,'Color',[0.4 0.4 0.4],'LineWidth',2);
line(xlim,repmat(noCLme.Coefficients.Estimate(1),1,2),'Color',[0.4 0.4 0.4],'LineWidth',2);
yticks([25:40]);
ylim([25 40]);

% So this is nice; centering makes it weird:

% - - - - - - - - - - - - - - - 
% Example 2.2: Uncentered case
subData = data_LFPrePost(data_LFPrePost.PrePost==2,:);
subData = LMEDemo_CenterL1L2(subData,'SbId',{'Segment'});

cLme = fitlme(subData,'VAS1 ~ c1Segment + (1|SbId)','StartMethod','default','FitMethod','REML')

figure;
S1 = subplot(1,2,1);
hold on;    
scatter(subData.Segment,predict(noCLme),'kx');
xlim([-0.5 6.5]);
ylim(S1.YLim);
lsline;
xlabel('Segment');
ylabel('Predicted VAS');       

% zoom in
line([0 0],ylim,'Color',[0.4 0.4 0.4],'LineWidth',2);
line(xlim,repmat(noCLme.Coefficients.Estimate(1),1,2),'Color',[0.4 0.4 0.4],'LineWidth',2);
yticks([30:40]);
ylim([30 40]);

S2 = subplot(1,2,2);
hold on;
scatter(subData.Segment,predict(cLme),'kx')           
xlim([-0.5 6.5]);
lsline;
xlabel('Segment (mean centered)');
ylabel('Predicted VAS');    

% zoom in
line([3.5 3.5],ylim,'Color',[0.4 0.4 0.4],'LineWidth',2);
line(xlim,repmat(cLme.Coefficients.Estimate(1),1,2),'Color',[0.4 0.4 0.4],'LineWidth',2);
yticks([30:40]);
ylim([30 40]);    

% - - - - - - - - - - - - - - - 
% Example 2.3: Comparing centered and uncentered estimates (main effects only)
subData = data_LFPrePost(data_LFPrePost.PrePost==2,:);
subData = LMEDemo_CenterL1L2(subData,'SbId',{'Segment','Session'});

lme1 = fitlme(subData,'VAS1 ~ c1Segment+Session + (1|SbId)','StartMethod','default','FitMethod','REML')
lme2 = fitlme(subData,'VAS1 ~ c1Segment+c1Session + (1|SbId)','StartMethod','default','FitMethod','REML')
% => no changes in betas to non-centered interactions
% => only intercept changes

figure;
S1 = subplot(1,2,1);
hold on;   
title('One predictor centered')
scatter(subData.Segment,predict(lme1),'kx');
xlim([-0.5 6.5]);
ylim(S1.YLim);
lsline;
xlabel('Segment (mean centered)');
ylabel('Predicted VAS');       

% zoom in
line([3.5 3.5],ylim,'Color',[0.4 0.4 0.4],'LineWidth',2);
line(xlim,repmat(lme1.Coefficients.Estimate(1),1,2),'LineStyle','--','Color',[0.4 0.4 0.4],'LineWidth',2);
yticks([25:40]);
ylim([25 40]);

S2 = subplot(1,2,2);    
hold on;
title('Both predictors centered')
scatter(subData.Segment,predict(lme2),'kx')           
xlim([-0.5 6.5]);
lsline;
xlabel('Segment (mean centered)');
ylabel('Predicted VAS');    

% zoom in
line([3.5 3.5],ylim,'Color',[0.4 0.4 0.4],'LineWidth',2);
line(xlim,repmat(lme2.Coefficients.Estimate(1),1,2),'Color',[0.4 0.4 0.4],'LineWidth',2);
yticks([25:40]);
ylim([25 40]);        

% So why is the uncentered case so weird?
u = unique(lme1.Variables.Session)
m = mean(u)
mSessionEffect = lme1.Coefficients.Estimate(strcmp(lme1.Coefficients.Name,'Session'))*m
lme1.Coefficients.Estimate(strcmp(lme1.Coefficients.Name,'(Intercept)'))+mSessionEffect   

% => mean of variables required to understand values
% => we center continuous predictors 
%    - to facilitate interpretation of betas
%    - to distinguish between first and second level variance

% - - - - - - - - - - - - - - -     
% Example 2.4: Comparing centered and uncentered estimates (main effects & interactions)
% The issue with non-centered variables are enhanced if we use interactions
% because if you do not center, you cannot interpret things separately anymore
subData = data_LFPrePost(data_LFPrePost.PrePost==2,:);
subData = LMEDemo_CenterL1L2(subData,'SbId',{'Segment','Session'});

lme1 = fitlme(subData,'VAS1 ~ c1Segment*Session + (1|SbId)','StartMethod','default','FitMethod','REML')
lme2 = fitlme(subData,'VAS1 ~ c1Segment*c1Session + (1|SbId)','StartMethod','default','FitMethod','REML')  

%[ones(size(subData,1),1) subData.Session subData.c1Segment subData.Session.*subData.c1Segment].*lme1.Coefficients.Estimate'

xb0 = repmat(lme1.Coefficients.Estimate(1),6,1);
x1 = repmat(mean(unique(lme1.Variables.Session)),6,1);
b1 = repmat(lme1.Coefficients.Estimate(strcmp(lme1.Coefficients.Name,'Session')),6,1);
x2 = unique(lme1.Variables.c1Segment);
b2 = repmat(lme1.Coefficients.Estimate(strcmp(lme1.Coefficients.Name,'c1Segment')),6,1);
x3 = x1.*x2;
b3 = repmat(lme1.Coefficients.Estimate(strcmp(lme1.Coefficients.Name,'Session:c1Segment')),6,1);

T1 = table(xb0,x1,b1,x1.*b1,x2,b2,x2.*b2,x3,b3,x3.*b3,xb0+x1.*b1+x2.*b2+x3.*b3);
T1.Properties.VariableNames([4 7 10 11]) = {'x1_b1','x2_b2','x3_b3','yHat'};

xb0 = repmat(lme2.Coefficients.Estimate(1),6,1);
x1 = repmat(mean(unique(lme2.Variables.c1Session)),6,1);
b1 = repmat(lme2.Coefficients.Estimate(strcmp(lme2.Coefficients.Name,'c1Session')),6,1);
x2 = unique(lme2.Variables.c1Segment);
b2 = repmat(lme2.Coefficients.Estimate(strcmp(lme2.Coefficients.Name,'c1Segment')),6,1);
x3 = x1.*x2;
b3 = repmat(lme2.Coefficients.Estimate(strcmp(lme2.Coefficients.Name,'c1Segment:c1Session')),6,1); % order!!

T2 = table(xb0,x1,b1,x1.*b1,x2,b2,x2.*b2,x3,b3,x3.*b3,xb0+x1.*b1+x2.*b2+x3.*b3);
T2.Properties.VariableNames([4 7 10 11]) = {'x1_b1','x2_b2','x3_b3','yHat'};    

% compare
T1
T2

% Conclusion: In order to facilitate interpretation, we center

% - - - - - - - - - - - - - - -     
% EXCOURSE
% Intercept, main effects and interactions

% - - - - - - - - - - - - - - -     
% Example 2.5 [optional]: Centering to disentangle level 1 and level 2 variance
subData = data_LFPrePost(data_LFPrePost.Segment==1 & data_LFPrePost.PrePost==2,:); % variation on Session level (kind of)
subData = LMEDemo_CenterL1L2(subData,'SbId',{'Session','MDBF_CalmNervous'});

lme = fitlme(subData,'VAS1 ~ c1MDBF_CalmNervous + (1|SbId)','StartMethod','default','FitMethod','REML');
lme = fitlme(subData,'VAS1 ~ c1Session*c1MDBF_CalmNervous + (1|SbId)','StartMethod','default','FitMethod','REML');
lme = fitlme(subData,'VAS1 ~ c2MDBF_CalmNervous + (1|SbId)','StartMethod','default','FitMethod','REML');
lme = fitlme(subData,'VAS1 ~ c1Session*c2MDBF_CalmNervous + (1|SbId)','StartMethod','default','FitMethod','REML') % demo     

% EXCOURSE: Continuous predictor plots
LMEDemo_ContinuousPlot(lme,'c2MDBF_CalmNervous','c1Session')    

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% - - - - - - - - - - - - - - -     
% - - - - - - - - - - - - - - - 
% - - - - - - - - - - - - - - - 
% 3 Categorical predictor variables
% First, well, categorize them
subData = data_LFDeltas;
subData = LMEDemo_CenterL1L2(subData,'SbId',{'Modality','Condition','collCondition'});
subData.nModality = categorical(subData.Modality,[1 2],{'Pain','Grill'});
subData.nCollCondition = categorical(data_LFDeltas.Condition,[1 2 3],{'Experimental','Control','Control'}); 

% Example 3.1: (somewhat) special case: dichotomous predictor
lme2 = fitlme(subData,'DeltaVAS1 ~ nModality + (1|SbId)','StartMethod','default','FitMethod','REML')
m1 = mean(subData.DeltaVAS1(subData.Modality==1))
m2 = mean(subData.DeltaVAS1(subData.Modality==2))
diff([m1 m2])

lme1 = fitlme(subData,'DeltaVAS1 ~ c1Modality + (1|SbId)','StartMethod','default','FitMethod','REML')
xb0 = lme1.Coefficients.Estimate(1)
b1 = lme1.Coefficients.Estimate(2)
x = unique(lme1.Variables.c1Modality)' % post-centering values
xb0+b1*x
% identical results except intercept

% - - - - - - - - - - - - - - -     
% Example 3.2 [optional]: more complicated with 3+ categories
subData = data_LFDeltas;
subData = LMEDemo_CenterL1L2(subData,'SbId',{'Modality','Condition','collCondition'});    
subData.nCondition = categorical(subData.Condition,[1 2 3],{'Experimental','Control1','Control2'}); 
lme1 = fitlme(subData,'DeltaVAS1 ~ c1Condition + (1|SbId)','StartMethod','default','FitMethod','REML')
lme2 = fitlme(subData,'DeltaVAS1 ~ nCondition + (1|SbId)','StartMethod','default','FitMethod','REML')

% - - - - - - - - - - - - - - -     
% Example 3.3: Understanding the reference category
subData = data_LFDeltas; 
subData.nCondition = categorical(subData.Condition,[1 2 3],{'Experimental','Control1','Control2'}); 
lme = fitlme(subData,'DeltaVAS1 ~ nCondition + (1|SbId)','StartMethod','default','FitMethod','REML')

subData = data_LFDeltas; 
subData.nCondition = categorical(subData.Condition,[2 1 3],{'Control1','Experimental','Control2'}); 
lme = fitlme(subData,'DeltaVAS1 ~ nCondition + (1|SbId)','StartMethod','default','FitMethod','REML')    

% - - - - - - - - - - - - - - - 
% EXCOURSE
% Why bother if we can do ANOVA? Or anova(lme)?
% 
% Even besides random effects, LME has many advantages over ANOVA, particularly for handling repeated measures data
% - Repeated measures can be treated as continuous
% - Missing data over occasions is handled well
% - Can have unequal number of cases
% - Can also have unequal intervals between measurement occasions across cases
% - Can test individual differences in growth curves
% - Can also include time-related level 1 predictors (such as days in study, age, mood, etc)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% - - - - - - - - - - - - - - -     
% - - - - - - - - - - - - - - - 
% - - - - - - - - - - - - - - - 
% 4 Handling results

% Example 4.1: In the case of multiple categorical predictors, one-analysis-to-rule-them-all?
subData = data_LFDeltas;
subData = LMEDemo_CenterL1L2(subData,'SbId',{'Segment'});    
subData.nModality = categorical(subData.Modality,[1 2],{'Pain','Grill'});     
subData.nCondition = categorical(subData.Condition,[1 2 3],{'Experimental','Control1','Control2'});      
subData.nCollCondition = categorical(subData.Condition,[1 2 3],{'Experimental','Control','Control'});     
rng(2022);
lme1 = fitlme(subData,'DeltaVAS1 ~ c1Segment+nModality*nCondition + (1|SbId)','StartMethod','random','FitMethod','REML','CheckHessian',true)

% "inelegant" approach
subData.nModality_s2 = categorical(subData.Modality,[2 1],{'Grill','Pain'});     
rng(2022);
lme2 = fitlme(subData,'DeltaVAS1 ~ c1Segment+nModality_s2*nCondition + (1|SbId)','StartMethod','random','FitMethod','REML','CheckHessian',true)

% - - - - - - - - - - - - - - -     
% Example 4.2: Introducing coefTest
% => CAVE: coefTest F1 => WRONG COEFTEST! Go via LinearMixedModel
% => Use coefTest for DF correction; Satterthwaite correction is valid for both balanced and unbalanced designs 
%    (i.e. unequal number of observations), as well as small sample sizes
lme1.Coefficients(2,:)
[p,~,~,DF2] = coefTest(lme1,[0 1 0 0 0 0 0],[0],'DFMethod','satterthwaite')

% - - - - - - - - - - - - - - -     
% Example 4.3: coefTest can be used to collapse conditions
subData.nCollCondition = categorical(subData.Condition,[1 2 3],{'Experimental','Control','Control'});   
rng(2022);
lme2 = fitlme(subData,'DeltaVAS1 ~ c1Segment+nModality*nCollCondition + (1|SbId)','StartMethod','random','FitMethod','REML','CheckHessian',true);

lme2.Coefficients(strcmp(lme2.Coefficients.Name,'nCollCondition_Control'),:)
[p,~,~,DF2] = coefTest(lme1,[0 0 0 1 1 0 0],[0],'DFMethod','satterthwaite')
[p,~,~,DF2] = coefTest(lme2,[0 0 0 1 0],[0],'DFMethod','satterthwaite')

% - - - - - - - - - - - - - - -     
% Example 4.4: coefTest can be used to extrapolate (non-)reference category effects
subData.nModality_s2 = categorical(subData.Modality,[2 1],{'Grill','Pain'});      
rng(2022);
lme1 = fitlme(subData,'DeltaVAS1 ~ c1Segment+nModality*nCondition + (1|SbId)','StartMethod','random','FitMethod','REML','CheckHessian',true);    
lme2 = fitlme(subData,'DeltaVAS1 ~ c1Segment+nModality_s2*nCondition + (1|SbId)','StartMethod','random','FitMethod','REML','CheckHessian',true);    

[p1OnPainRef,~,~,~] = coefTest(lme1,[0 0 0 1 1 0 0],[0],'DFMethod','satterthwaite') % local effect on pain
[p1OnGrillRef,~,~,~] = coefTest(lme1,[0 0 0 1 1 1 1],[0],'DFMethod','satterthwaite') % local effect on grill  
% proof
% [0 0 0 1 1 1 1] WOULD NOT WORK, but [0 0 1 1 0 1 1] will
conDef = LMEDemo_DefineCon(lme2,{'nCondition\_Control\d'},'T');
[p2OnPainRef,~,~,~] = coefTest(lme2,conDef,[0],'DFMethod','satterthwaite') % local effect on grill  
conDef = LMEDemo_DefineCon(lme2,{'(?<!\:)nCondition\_Control\d(?!\:)'},'T')
[p2OnGrillRef,~,~,~] = coefTest(lme2,conDef,[0],'DFMethod','satterthwaite') % local effect on grill      

% etc

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% - - - - - - - - - - - - - - -     
% - - - - - - - - - - - - - - - 
% - - - - - - - - - - - - - - - 
% 5. Random effects (REs)

% - - - - - - - - - - - - - - - 
% Example 5.1 [optional]: Benefit of REs
subData = data_LFPrePost(data_LFPrePost.PrePost==1,:);
subData = LMEDemo_CenterL1L2(subData,'SbId',{'Segment'});

lmeNoRE = fitlme(subData,'VAS1 ~ c1Segment + (1|SbId)','StartMethod','default','FitMethod','REML','CheckHessian',true)
lmeWRE = fitlme(subData,'VAS1 ~ c1Segment + (c1Segment|SbId)','StartMethod','default','FitMethod','REML','CheckHessian',true)

figure;

subplot(1,3,1);
hold on;
title('Without random effects');    
scatter(lmeNoRE.Variables.Segment,fitted(lmeNoRE),'kx')  
xlabel('Segment (mean centered)');
ylabel('Predicted VAS');   

subplot(1,3,2);
hold on;
title('With random effects');    
scatter(lmeWRE.Variables.Segment,fitted(lmeWRE),'kx')   
xlabel('Segment (mean centered)');
ylabel('Predicted VAS');   

subplot(1,3,3);
hold on;
title('Comparing with & without RE');    
scatter(fitted(lmeNoRE),fitted(lmeWRE),'kx')   
xlim([0 70]);
ylim(xlim);
xlabel('Predicted VAS (w/o RE)');   
ylabel('Predicted VAS (with RE)');   

% - - - - - - - - - - - - - - - 
% Example 5.2: How to assess whether inclusion is wortwhile?
% => Conceptually
% => Empirically
subData = data_LFDeltas;
subData = LMEDemo_CenterL1L2(subData,'SbId',{'Segment','Session'});
subData.nModality = categorical(subData.Modality,[1 2],{'Pain','Grill'});      
subData.nCondition = categorical(subData.Condition,[1 2 3],{'Experimental','Control1','Control2'});

% segment as RE
lmeNoRE = fitlme(subData,'DeltaVAS1 ~ c1Segment+nModality*nCondition + (1|SbId)','StartMethod','default','FitMethod','REML'); 
lmeWRE = fitlme(subData,'DeltaVAS1 ~ c1Segment+nModality*nCondition + (c1Segment|SbId)','StartMethod','default','FitMethod','REML');
lmeNoRE.Formula
lmeWRE.Formula
compare(lmeNoRE,lmeWRE)  

figure;
subplot(1,2,1);
hold on;
title('Without random effects');    
scatter(response(lmeNoRE),fitted(lmeNoRE),'kx') % or do sth like plot(R,F,'rx')
xlabel('Raw VAS')
ylabel('Predicted VAS')    

subplot(1,2,2);
hold on;
title('With random effects');    
scatter(response(lmeWRE),fitted(lmeWRE),'kx') % or do sth like plot(R,F,'rx')
xlabel('Raw VAS')
ylabel('Predicted VAS')    

% - - - - - - - - - - - - - - - 
% Example 5.3 [optional]: Full continuous+categorical example
subData = data_LFDeltas;
subData = LMEDemo_CenterL1L2(subData,'SbId',{'Segment','Session'});
subData.nModality = categorical(subData.Modality,[1 2],{'Pain','Grill'});      
subData.nCondition = categorical(subData.Condition,[1 2 3],{'Experimental','Control1','Control2'});

lmeWRE = fitlme(subData,'DeltaVAS1 ~ c1Segment+nModality*nCondition + (c1Segment|SbId)','StartMethod','default','FitMethod','REML')

sbFEs = fixedEffects(lmeWRE);
sbREs = randomEffects(lmeWRE); % WRONG!
[sbREs,bn] = randomEffects(lmeWRE); % right
ix_Intercept = cellfun(@(x) strcmp(x,'(Intercept)'),bn.Name); % because order is not always stable, we cannot rely on indices (e.g. 1:2:end)
ix_c1Segment = cellfun(@(x) strcmp(x,'c1Segment'),bn.Name); % because order is not always stable, we cannot rely on indices (e.g. 1:2:end) 
sbREs_Intercept = sbREs(ix_Intercept); % subject-specific random intercepts
sbREs_c1Segment = sbREs(ix_c1Segment); % subject-specific random slopes for Segment

allSbs = unique(subData.SbId);
segs = unique(subData.Segment)';
yHat = ( sbFEs(1)+1*sbREs_Intercept ) + ( segs.*sbFEs(2).*sbREs_c1Segment ) + 0 + 0 + 0;

figure;
axes;
hold on;
title('Segment effect (FE+RE)')
scatter(repelem(segs,1,numel(allSbs)),yHat(:),'kx');
plot(segs,yHat,'Color',[0 0 0],'LineWidth',1);
xlim([0.5 6.5]);

xlabel('Segment');
ylabel(['Predicted ' char(916) 'VAS']);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% - - - - - - - - - - - - - - -     
% - - - - - - - - - - - - - - - 
% - - - - - - - - - - - - - - - 
% TROUBLESHOOTING

% - - - - - - - - - - - - - - -     
% MATLAB quirks: variable sorting
% Ex 1
subData = data_LFPrePost(data_LFPrePost.PrePost==2,:);
subData = LMEDemo_CenterL1L2(subData,'SbId',{'Segment','Session'});

lme1 = fitlme(subData,'VAS1 ~ c1Segment+Session + (1|SbId)','StartMethod','default','FitMethod','REML')
lme2 = fitlme(subData,'VAS1 ~ c1Segment+c1Session + (1|SbId)','StartMethod','default','FitMethod','REML')

% Ex 2
subData = data_LFDeltas;
subData = LMEDemo_CenterL1L2(subData,'SbId',{'Segment'});    
subData.nModality = categorical(subData.Modality,[1 2],{'Pain','Grill'});     
subData.nModality_s2 = categorical(subData.Modality,[2 1],{'Grill','Pain'});     
subData.nCondition = categorical(subData.Condition,[1 2 3],{'Experimental','Control1','Control2'});      
rng(2022);
lme1 = fitlme(subData,'DeltaVAS1 ~ c1Segment+nModality*nCondition + (1|SbId)','StartMethod','random','FitMethod','REML','CheckHessian',true)
lme2 = fitlme(subData,'DeltaVAS1 ~ c1Segment+nModality_s2*nCondition + (1|SbId)','StartMethod','random','FitMethod','REML','CheckHessian',true)

conDef = LMEDemo_DefineCon(lme1,{'nCondition\_Control\d'},'T')
conDef = LMEDemo_DefineCon(lme2,{'nCondition\_Control\d'},'T')

% - - - - - - - - - - - - - - - 
% Design matrix issues: Deficient ranks
subData = data_LFDeltas;
subData = LMEDemo_CenterL1L2(subData,'SbId',{'Segment'});    
subData(subData.Modality==1 & subData.Condition==1,:) = []; % create error
subData.nModality = categorical(subData.Modality,[1 2],{'Pain','Grill'});     
subData.nCondition = categorical(subData.Condition,[1 2 3],{'Experimental','Control1','Control2'});      
try 
    lme = fitlme(subData,'DeltaVAS1 ~ nModality*nCondition + (1|SbId)','StartMethod','default','FitMethod','REML') % explain error
catch
    fprintf('¯\\_(%s)_/¯\n',char(hex2dec('30c4')));
end

% - - - - - - - - - - - - - - - 
% Hessian trouble 1: Nesting not properly calculated
subData = data_LFDeltas;
subData = LMEDemo_CenterL1L2(subData,'SbId',{'Segment'});    
subData.nModality = categorical(subData.Modality,[1 2],{'Pain','Grill'});     
subData.nModality_s2 = categorical(subData.Modality,[2 1],{'Grill','Pain'});     
subData.nCondition = categorical(subData.Condition,[1 2 3],{'Experimental','Control1','Control2'});      

lmeNull2 = fitlme(data_LFDeltas,'DeltaVAS1 ~ 1 + (1|SbId)','StartMethod','default','FitMethod','REML','CheckHessian',true);    
LMEDemo_Nesting(lmeNull2);

rng(2022);
lmeNull2 = fitlme(data_LFDeltas,'DeltaVAS1 ~ 1 + (1|SbId)','StartMethod','random','FitMethod','REML','CheckHessian',true);    
LMEDemo_Nesting(lmeNull2);        

% - - - - - - - - - - - - - - - 
% Hessian trouble 2: Estimation issues
subData = data_LFDeltas;
subData = LMEDemo_CenterL1L2(subData,'SbId',{'Segment'});    
subData.nModality = categorical(subData.Modality,[1 2],{'Pain','Grill'});     
subData.nModality_s2 = categorical(subData.Modality,[2 1],{'Grill','Pain'});     
subData.nCondition = categorical(subData.Condition,[1 2 3],{'Experimental','Control1','Control2'});      

lme = fitlme(subData,'DeltaVAS1 ~ c1Segment+nModality*nCondition + (1|SbId)','StartMethod','default','FitMethod','REML','CheckHessian',true)
% SOLUTION
rng(2022);
lme = fitlme(subData,'DeltaVAS1 ~ c1Segment+nModality*nCondition + (1|SbId)','StartMethod','random','FitMethod','REML','CheckHessian',true)
% possible alternative solution: increase iterations

% - - - - - - - - - - - - - - - 
% Hessian trouble 3: Non-recoverable issues
subData = data_LFDeltas;
subData = LMEDemo_CenterL1L2(subData,'SbId',{'Segment'});
subData.nModality = categorical(subData.Modality,[1 2],{'Pain','Grill'});      
subData.nCondition = categorical(subData.Condition,[1 2 3],{'Experimental','Control1','Control2'});

% Segment as RE
lmeW1RE = fitlme(subData,'DeltaVAS1 ~ c1Segment+nModality*nCondition + (c1Segment|SbId)','StartMethod','random','FitMethod','REML','CheckHessian',true)    
lmeW2RE = fitlme(subData,'DeltaVAS1 ~ c1Segment+nModality*nCondition + (c1Segment|SbId) + (nModality|SbId)','StartMethod','random','FitMethod','REML','CheckHessian',true)    
compare(lmeW1RE,lmeW2RE)     

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% - - - - - - - - - - - - - - -     
% - - - - - - - - - - - - - - - 
% - - - - - - - - - - - - - - - 
% FUTURE TOPICS

% - Alternatives to mean centering (e.g. time zero centering)
% - "When" to assign L1 covariates (e.g. pre/post questionnaires)
% - Alternatives to reference category coding via fitlme's 'DummyVarCoding' ('reference' (default) | 'effects' | 'full')
% - Effect sizes of LME (level 1, level 2, cross-level)
    