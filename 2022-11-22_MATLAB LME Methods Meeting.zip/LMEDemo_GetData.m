function [data,data_LFFull,data_LFPrePost,data_LFDeltas] = LMEDemo_GetData(baseDir)

    data = readtable(fullfile(baseDir,'data','data.txt')); 
    data_LFFull = data;
    data_LFPrePost =  data(data.NContact==2 | data.NContact==9,:);
    data_LFDeltas = data(data.NContact==5,:);
    
    