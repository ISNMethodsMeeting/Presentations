% Print nesting estimates for LME
%
% LMEDemo_GetLMENesting(lme)
% lme       - lme (fitlme object)
%
% Version: 1.0
% Author: Bjoern Horing, bjoern.horing@gmail.com
% Date: 2022-08-xx

function LMEDemo_Nesting(lme)

    if numel(lme.CoefficientNames)>1 && ~strcmp(lme.CoefficientNames{1},'(Intercept)')
        warning('Nesting is only calculated using the null model.');
        return;
    end
        
    withinVar = lme.MSE;
    T = LMEDemo_CenterL1L2(lme.Variables,'SbId',{lme.ResponseName});
    subjectBetweenVar = std(T.(['c2' lme.ResponseName]),'omitnan')^2; % more conservative
    ICC1Est1 = subjectBetweenVar/(withinVar+subjectBetweenVar);
    
    [x4,y,blups] = randomEffects(lme); % more liberal 
    REVar = std(x4,'omitnan')^2;
    ICC1Est2 = REVar/(withinVar+REVar);

    fprintf('---------------------------------------------------------------------\n');
    fprintf('Determine degree of nesting\n');
    fprintf('\tFormula: MSE(between)/(MSE(between)+MSE(within)) in NULL model\n');
    fprintf('\tNull model: %s\n',lme.Formula);
    fprintf('\tMSE(betweenNoRE) = %1.1f, MSE(betweenRE) = %1.1f, MSE(within) = %1.1f\n',subjectBetweenVar,REVar,withinVar);
    fprintf('\tDegree of nesting (liberal) is %1.1f%%.\n',ICC1Est1*100)
    fprintf('\tDegree of nesting (conservative) is %1.1f%%.\n',ICC1Est2*100)
    
