function [path,vars,analysis,import] = get_study_specs


%% import definitions


import.prisma        = {{23256}, {23295}};
import.prisma_no     = [1      ,3       ];
                    
import.user          = 'buechel';
import.server        = 'revelations.nin.uke.uni-hamburg.de';

r = 1;

import.data(r).dir        = 'func';
import.data(r).type       = 'bold';
import.data(r).seq        = 'ninEPI_bold_v12C, kombi-pmb';
%import.data(r).cond       = 'n == 112 || n == 464 || n == 104 || n == 224';
import.data(r).cond       = 'n == 112'; %just get the small runs 
r = r + 1;

import.data(r).dir        = 'anat';
import.data(r).type       = 'T1w';
import.data(r).seq        = 'mprage, 1x1x1mm3, SAG, slc-sel ';
import.data(r).cond       = 'n == 192';
r = r + 1;

import.data(r).dir        = 'anat';
import.data(r).type       = 'T2w';
import.data(r).seq        = 'T2w,not_iso';
import.data(r).cond       = 'n == 64';
r = r + 1;

import.data(r).dir        = 'fmap';
import.data(r).type       = 'phasediff';
import.data(r).seq        = 'gre_field_map, cospi ';
import.data(r).cond       = 'n == 60';
r = r + 1;

import.data(r).dir        = 'fmap';
import.data(r).type       = 'magnitude';
import.data(r).seq        = 'gre_field_map, cospi ';
import.data(r).cond       = 'n == 120';
r = r + 1;
 
import.dummies            = 3; 
%% path definitions

%% path definitions
path.baseDir     = 'd:\tutorial2\';
path.templateDir = 'd:\peep\spm_bids_pipeline\tutorial2\'; 

path.derivDir        = fullfile(path.baseDir, 'derivatives');
path.preprocDir      = fullfile(path.baseDir, 'derivatives', 'spm_preprocessing');
path.firstlevelDir   = fullfile(path.baseDir, 'derivatives', 'spm_firstlevel');
path.secondlevelDir  = fullfile(path.baseDir, 'derivatives', 'spm_secondlevel');

%% vars definitions

% various predefined names (change only if you know what you are doing)
vars.skullStripID    = 'skull-strip-T1.nii';
vars.T1maskID        = 'brain_mask.nii';
vars.templateID      = 'cb_Template_%d_Dartel.nii';
vars.templateT1ID    = 'cb_Template_T1.nii';
%vars.groupMaskID     = 'brainmask.nii';
vars.groupMaskID     = 'neuromorphometrics.nii'; 


%% this need to be adapted to your study / computer--------------
vars.max_procs   = 12;
vars.task        = 'cpm';
vars.nRuns       = Inf;
vars.nSess       = Inf;
% get info for slice timing correction
vars.sliceTiming.so    = []; % in ms
vars.sliceTiming.tr       = 1.8; % in s
vars.sliceTiming.nslices  = [];
vars.sliceTiming.refslice = [];

analysis = []; %for now
end