function [path,vars,analysis,import] = get_study_specs

%% path definitions
path.baseDir     = 'd:\tutorial\';
path.templateDir = 'd:\tutorial\spm_bids_pipeline\templates\';

import.prisma        = {{11658,11672},{11808,11815}}; % translates to PRISMA_nnn (or TRIO_nnn see below)
import.prisma_no     = [1            ,4            ]; % subject number

import.user          = 'buechel';
import.server        = 'revelations.nin.uke.uni-hamburg.de';

import.scanner       = 'TRIO'; % flag to say we have a TRIO number (can be left undefined for PRISMA)                  

import.data(1).dir        = 'func'; 
import.data(1).type       = 'bold';
import.data(1).seq        = 'nin_ep2d_bold_vb8_fcross '; %protocol name (trailing space makes it unique) 
import.data(1).cond       = 'n > 500'; % heuristic to get only valid runs (e.g. more than 1000 volumes)

import.data(2).dir        = 'anat'; % valid BIDS dir name
import.data(2).type       = 'T1w'; % valid BIDS file name
import.data(2).seq        = 'mprage, 1x1x1mm3, COR, ns, 32-channel ';
import.data(2).cond       = 'n == 240'; % heuristic to get only valid runs (e.g. exactly 240 slices)
 
import.dummies            = 4; % these scans are removed when merging 3D epifiles to a 4D file

path.derivDir        = fullfile(path.baseDir, 'derivatives');
path.preprocDir      = fullfile(path.baseDir, 'derivatives', 'spm_preprocessing');
path.firstlevelDir   = fullfile(path.baseDir, 'derivatives', 'spm_firstlevel');
path.secondlevelDir  = fullfile(path.baseDir, 'derivatives', 'spm_secondlevel');

%% vars definitions

% various predefined names (change only if you know what you are doing)
vars.skullStripID    = 'skull-strip-T1.nii';
vars.T1maskID        = 'brain_mask.nii';
vars.templateID      = 'cb_Template_%d_Dartel.nii';
vars.templateT1ID    = 'cb_Template_T1.nii';
vars.groupMaskID     = 'neuromorphometrics.nii';

%% this need to be adapted to your study / computer--------------
vars.task        = 'malepain';
% get info for slice timing correction
vars.sliceTiming.tr       = 2.58; % in s

analysis = [];
end