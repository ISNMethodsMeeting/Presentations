---
category: literaturenote
cssclasses:
  - literature-note
citekey: "{{citekey}}"
dateread:
---
>[!Tags]
>{%- if hashTags %} 
>{{hashTags}} 
>{%- endif %}

---
# {{title}}

> [!Cite] 
> ### {{bibliography}} 

>[!Abstract]
>{{abstractNote}}
>

>[!Synth]
>**StudyType**:: {% set hasTag1 = false %}{% set hasTag2 = false %}{% for tag in tags %}{% if tag.tag == "Review" %} {% set hasTag1 = true %}{% endif %}{% if tag.tag == "review" %}{% set hasTag2 = true %}{% endif %}{% endfor %} {% if hasTag1 or hasTag2 %}Review{% else %}Experiment{% endif %}
>**Related**:: {% for relation in relations | selectattr("citekey") %} [[{{relation.citekey}}]]{% if not loop.last %}, {% endif%} {% endfor %}
> __Further relations__
> *Cited_by*:: {% persist "Cited by" %} {% endpersist %}
> *Citing*:: {% persist "Citing" %} {% endpersist %}
> **WhyRead**:: {% persist "WhyRead" %} {% endpersist %}
> **Source**:: {% persist "Source" %} {% endpersist %}

>[!info] Contribution
>**Contribution**:: {% persist "Contribution" %} {% endpersist %}

  
>[!md]  
{% for type, creators in creators | groupby("creatorType") -%}  
{%- for creator in creators -%}  
>**{{"First" if loop.first}}{{type | capitalize}}**::  
{%- if creator.name %} {{creator.name}}  
{%- else %} {{creator.lastName}}, {{creator.firstName}}  
{%- endif %}  
{% endfor %}--
{%- endfor %}  
>**Title**:: {{title}}
>--  
>**Year**:: {{date | format("YYYY")}}  
>**Citekey**:: {{citekey}} {%- if itemType %}  
>**itemType**:: {{itemType}}{%- endif %}{%- if itemType == "journalArticle" %}  
>**Journal**:: *{{publicationTitle}}* {%- endif %}{%- if volume %}  
>**Volume**:: {{volume}} {%- endif %}{%- if issue %}  
>**Issue**:: {{issue}} {%- endif %}{%- if itemType == "bookSection" %}  
>**Book**:: {{publicationTitle}} {%- endif %}{%- if publisher %}  
>**Publisher**:: {{publisher}} {%- endif %}{%- if place %}  
>**Location**:: {{place}} {%- endif %}{%- if pages %}  
>**Pages**:: {{pages}} {%- endif %}{%- if DOI %}  
>**DOI**:: {{DOI}} {%- endif %}{%- if ISBN %}  
>**ISBN**:: {{ISBN}} {%- endif %}{%- if hashTags %}
>**Tags**::   {{hashTags}} {%- endif %}

>[!Link]
>{%- for attachment in attachments | filterby("endswith", ".pdf") %}  
>[{{attachment.title}}](file:///{{attachment.path | replace(" ", "%20")}}) {%- endfor -%}.

{%-
set colorOrder = ["Red","Orange","Yellow","Green","Gray","Blue","Magenta"]
-%}

{%- macro colorValueToName(colorCategory) -%} 
{%- switch colorCategory -%}
{%- case "Red" -%} Hypotheses/Research Question
{%- case "Orange" -%} Main Results 
{%- case "Yellow" -%} Relevant / important 
{%- case "Green" -%} Interesting
{%- case "Gray" -%} Methodological Stuff
{%- case "Blue" -%} Definitions/Concepts
{%- case "Magenta" -%} Read these References
{%- endswitch -%} 
{%- endmacro -%}

{%- macro calloutHeader(type) -%} 
{%- switch type -%} 
{%- case "highlight" -%} Highlight 
{%- case "strike" -%} Strikethrough 
{%- case "underline" -%} Underline 
{%- case "image" -%} Image 
{%- default -%} Note 
{%- endswitch -%} 
{%- endmacro %}
# Notes
{% persist "notes" %}
{% endpersist %}
# Annotations  
{% persist "annotations" %} 
{% set annots = annotations | filterby("date", "dateafter", lastImportDate) -%} 
{% if annots.length > 0 %} 
### Imported on {{importDate | format("YYYY-MM-DD h:mm a")}}

{% for color in colorOrder -%} 
#### {{colorValueToName(color)}} 

{% for annot in annots | filterby("colorCategory","startswith",color) -%}

{% if annot.source == "pdf" or annot.type == "image"-%}

> [!quote{% if annot.color %}|{{annot.color}}{% endif %}] {{calloutHeader(annot.type)}}
{%- if annot.annotatedText %}
> {{annot.annotatedText | nl2br}}
{%- endif -%}
{%- if annot.imageRelativePath %}
> ![[{{annot.imageRelativePath}}]]
{%- endif %}
{%- if annot.ocrText %}
> {{annot.ocrText}}
{%- endif %}
{%- if annot.comment %}
>
>> {{annot.comment | nl2br}}
{%- endif %}
>
> [Page {{annot.page}}](zotero://open-pdf/library/items/{{annot.attachment.itemKey}}?page={{annot.page}}) {{annot.date | format("YYYY-MM-DD#h:mm a")}}

{% endif -%}
{% endfor -%}
{% endfor -%}
{% endif %}
{% endpersist %}


