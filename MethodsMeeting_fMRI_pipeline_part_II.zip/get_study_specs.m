function [path,vars,analysis,import] = get_study_specs

%% path definitions
path.baseDir     = 'd:\tutorial\';
path.templateDir = 'd:\tutorial\spm_bids_pipeline\templates\';

import.prisma        = {{11658,11672},{11808,11815}}; % translates to PRISMA_nnn (or TRIO_nnn see below)
import.prisma_no     = [1            ,2            ]; % subject number

import.user          = 'buechel';
import.server        = 'revelations.nin.uke.uni-hamburg.de';

import.scanner       = 'TRIO'; % flag to say we have a TRIO number (can be left undefined for PRISMA)                  

import.data(1).dir        = 'func'; 
import.data(1).type       = 'bold';
import.data(1).seq        = 'nin_ep2d_bold_vb8_fcross '; %protocol name (trailing space makes it unique) 
import.data(1).cond       = 'n > 500'; % heuristic to get only valid runs (e.g. more than 1000 volumes)

import.data(2).dir        = 'anat'; % valid BIDS dir name
import.data(2).type       = 'T1w'; % valid BIDS file name
import.data(2).seq        = 'mprage, 1x1x1mm3, COR, ns, 32-channel ';
import.data(2).cond       = 'n == 240'; % heuristic to get only valid runs (e.g. exactly 240 slices)
 
import.dummies            = 4; % these scans are removed when merging 3D epifiles to a 4D file

path.derivDir        = fullfile(path.baseDir, 'derivatives');
path.preprocDir      = fullfile(path.baseDir, 'derivatives', 'spm_preprocessing');
path.firstlevelDir   = fullfile(path.baseDir, 'derivatives', 'spm_firstlevel');
path.secondlevelDir  = fullfile(path.baseDir, 'derivatives', 'spm_secondlevel');

%% vars definitions

% various predefined names (change only if you know what you are doing)
vars.skullStripID    = 'skull-strip-T1.nii';
vars.T1maskID        = 'brain_mask.nii';
vars.templateID      = 'cb_Template_%d_Dartel.nii';
vars.templateT1ID    = 'cb_Template_T1.nii';
vars.groupMaskID     = 'neuromorphometrics.nii';

%% this need to be adapted to your study / computer--------------
vars.max_procs   = 12;
vars.task        = 'malepain';
vars.nRuns       = 1;
vars.nSess       = 2;
% get info for slice timing correction
vars.sliceTiming.so       = [2527.50,2465.00,2405.00,2342.50,2280.00,2220.00,2157.50,2095.00,2035.00,1972.50,1910.00,1850.00,1787.50,1725.00,1665.00,1602.50,1540.00,1480.00,1417.50,1355.00,1295.00,1232.50,1170.00,1110.00,1047.50,985.00,925.00,862.50,800.00,740.00,677.50,615.00,555.00,492.50,430.00,370.00,307.50,245.00,185.00,122.50,60.00,0.00]; % in ms
vars.sliceTiming.tr       = 2.58; % in s
vars.sliceTiming.nslices  = 40;
vars.sliceTiming.refslice = 1290; % middle slice in ms

 
analysis = [];
end