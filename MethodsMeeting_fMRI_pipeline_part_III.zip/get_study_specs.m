function [path,vars,analysis,import] = get_study_specs

%% path definitions
path.baseDir     = 'd:\tutorial2\';
path.templateDir = 'd:\tutorial2\spm_bids_pipeline\templates\';
vars.max_procs   = 12;

import.prisma        = {{17468},{17476},{17477},{17478},{17479},{17480},{17481},{17482},{17483},{17484},...
    {17485},{17486},{17487},{17488},{17514},{17515},{17516},{17517},{17520},{17521},...
    {17522},{17523},{17524},{17525},{17526},{17527},{17557},{17558},{17559},{17560},...
    {17563},{17564},{17565},{17566},{17567},{17568},{17569},{17570},{17571},{17572}}; % translates to TRIO_nnn
import.prisma_no     = [5:44]; % subject number

% import.prisma        = {{17468}};
% import.prisma_no     = [5];


import.scanner       = 'TRIO'; % dirty flag to say we have a TRIO number

import.user          = 'buechel';
import.server        = 'revelations.nin.uke.uni-hamburg.de';

import.data(1).dir        = 'func';
import.data(1).type       = 'bold';
import.data(1).seq        = 'nin_ep2d_bold_vb10.6, 1.5mm3, mb2 '; %protocol name (trailing space makes it unique)
import.data(1).cond       = 'n > 800'; % heuristic to get only valid runs (e.g. more than 1000 volumes)

import.data(2).dir        = 'anat'; % valid BIDS dir name
import.data(2).type       = 'T1w'; % valid BIDS file name
import.data(2).seq        = 'mprage, 1x1x1mm3, COR ';
import.data(2).cond       = 'n == 240'; % heuristic to get only valid runs (e.g. exactly 240 slices)

import.dummies            = 0; % these scans are removed when merging 3D epifiles to a 4D file

path.derivDir        = fullfile(path.baseDir, 'derivatives');
path.preprocDir      = fullfile(path.baseDir, 'derivatives', 'spm_preprocessing');
path.firstlevelDir   = fullfile(path.baseDir, 'derivatives', 'spm_firstlevel');
path.secondlevelDir  = fullfile(path.baseDir, 'derivatives', 'spm_secondlevel');

%% vars definitions

% various predefined names (change only if you know what you are doing)
vars.skullStripID    = 'skull-strip-T1.nii';
vars.T1maskID        = 'brain_mask.nii';
vars.templateID      = 'cb_Template_%d_Dartel.nii';
vars.templateT1ID    = 'cb_Template_T1.nii';
vars.groupMaskID     = 'neuromorphometrics.nii';

%% this need to be adapted to your study / computer--------------
vars.task        = 'fearamy';
vars.nRuns       = 3;
vars.nSess       = 1;
% get info for slice timing correction
% get info for slice timing correction
vars.sliceTiming.so       = [917.50, 840.00, 765.00, 687.50, 610.00, 535.00, 457.50, 382.50, 305.00, 230.00, 152.50, 75.00, 0.00,...
    917.50, 840.00, 765.00, 687.50, 610.00, 535.00, 457.50, 382.50, 305.00, 230.00, 152.50, 75.00, 0.00]; % in ms
% found in --> times = str2num(strvcat(a{1}.CSAImageHeaderInfo(81).item.val))';
vars.sliceTiming.tr       = 0.99; % in s
vars.sliceTiming.nslices  = 26;
vars.sliceTiming.refslice = 500;


% the next section can be used to define different groups for 2nd level analysis
analysis.all_subs  = [5:9 12 14 16:21 24 25 27 28 30 32 34]; % 20 subjects;

single_group       = ones(size(analysis.all_subs));
analysis.group_ind  = single_group; %index 1
analysis.group_weights = [1];
analysis.group_names   = {'All'};


% pat_o_con             = [1 1 2 1 2 2 1 1 1 1 2 1 2 1 2 2 2 1 1 2];
% analysis.group_ind  = pat_o_con; %index 1 and 2
% analysis.group_weights = [1 1;1 -1;-1 1];
% analysis.group_names   = {'All','Pat>Con','Con>Pat'};
 

%analysis.max_procs         = 12; % how many processes can be used for 1st level analyses
analysis.parallel          = 1;
analysis.noise_corr        = ['mov24_wm_csf_roi']; % can contain any combination of "mov6" "mov24" "wm" "csf" "roi" "physio" "other"

analysis.cvi               = 'none'; % any of "AR(1)"  "FAST" "none" "wls" the latter uses J. Diedrichsen toolbox to do WLS https://www.diedrichsenlab.org/imaging/robustWLS.html
analysis.shift             = 0; % shift all onsets by n TRs
analysis.skernel           = 6; % smoothing kernel
analysis.hpf               = 120;
analysis.bs                = 0; % do brainstem specific analysis
analysis.use_vasa          = 0; % do vasa correction https://www.sciencedirect.com/science/article/pii/S1053811915008484

% what to do 1st level
analysis.do_model          = 0; % specify the model
analysis.do_est            = 0; % estimate the model
analysis.do_vasa           = 0; % estimate Vasa image for correction
analysis.do_cons           = 0; % do contrasts
analysis.do_correct_vasa   = 0; % correct con images using Vasa image
analysis.do_warp           = 0; % warp native space con or beta images to template space
analysis.do_smooth         = 0; % smooth these warped beta and con images

% what to do second level
analysis.do_fact           = 1; % simple anova that reproduces the 1st level at the 2nd level
analysis.do_fact_con       = 1; % do all contrasts at the second level

analysis.do_one_t          = 0; % instead use the estimated cons from 1st level and do one sample t tests


%% some code to organise the analyses
do_hrf_cond               = 0; %
do_hrf_param_rep_mbi      = 1; %

if do_hrf_cond
    [analysis.t_con, analysis.t_con_names] = get_hrf_cons_cond;
    analysis.max_procs         = 10;
    analysis.concatenate       = 1; % concatenate ?
    analysis.ana               = 2; % 1=FIR, 2=HRF 3=LS-A
    analysis.n_base            = 1;
    analysis.name_ana          = 'fearamy_hrf_cond';
    analysis.events            = ''; % original tsv file
    analysis.cond_names        = {'-135','-90','-45','0','45','90','135','180','225','270','315','360','405','450','495','540'}; % events
    analysis.p_mod             = {{}    ,{}   ,{}   ,{} ,{}  ,{}  ,{}   ,{}   ,{}   ,{}   ,{}   ,{}   ,{}   ,{}   ,{}   ,{}   }; % no parametric modulators
end

if do_hrf_param_rep_mbi
    [analysis.t_con, analysis.t_con_names] = get_hrf_cons_param_rep_mbi;
    analysis.max_procs         = 10;
    analysis.concatenate       = 1; % concatenate ?
    analysis.ana               = 2; % 1=FIR, 2=HRF 3=LS-A
    analysis.n_base            = 1;
    analysis.name_ana          = 'fearamy_hrf_param_rep_mbi';
    analysis.events            = '_param'; % this refers to the tsv file: *_param.tsv
    analysis.cond_names        = {'face'                                      ,'c_face'            }; % 2 conditions
    analysis.p_mod             = {{'p_tune','p_rtime','p_mbi','p_tune_x_mbi'} ,{'p_tune','p_rtime','p_mbi','p_tune_x_mbi'}}; % parametric modulators
end

    function [t_con, t_con_names] = get_hrf_cons_cond
        tuning      = [-0.2844   -0.0979    0.2804    0.5343    0.2804   -0.0979   -0.2844   -0.3304]; % vanmises k=1;
        t_con       = [[ones(1,8) zeros(1,8)];[ones(1,16)];[tuning zeros(1,8)];[-tuning zeros(1,8)];[tuning tuning];[-tuning -tuning]];
        t_con_names = {'faces_valid'         ,'faces_all' ,'tuning_valid'     ,'neg_tuning_valid'  ,'tuning_all'   ,'neg_tuning_all'};
    end

    function [t_con, t_con_names] = get_hrf_cons_param_rep_mbi
        all_con             = [eye(5) zeros(5)];
        t_con               = [all_con;-all_con];
        t_con_names         = {'f','f_tune','f_rtime','f_mbi','f_tune_x_mbi'};
        t_con_names         = [t_con_names strcat(t_con_names,'_neg')];
    end


end